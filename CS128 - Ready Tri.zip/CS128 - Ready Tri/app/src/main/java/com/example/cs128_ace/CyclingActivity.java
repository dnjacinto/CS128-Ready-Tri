package com.example.cs128_ace;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;

public class CyclingActivity extends AppCompatActivity {
    CheckBox c1, c2, c3, c4, c5, c6, c7, c8, c9, c10, c11, c12, c13, c14, c15;
    private Button button_return;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cycling);

        //back button
        button_return = (Button) findViewById(R.id.button_return);
        button_return.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                openMainActivity();
            }
        });

        //save state

        CheckBox checkBox_bike_item_1 = (CheckBox) findViewById(R.id.checkBox_bike_item_1);
        boolean checked1 = PreferenceManager.getDefaultSharedPreferences(this)
                .getBoolean("checkBox_bike_item_1", false);
        checkBox_bike_item_1.setChecked(checked1);

        CheckBox checkBox_bike_item_2 = (CheckBox) findViewById(R.id.checkBox_bike_item_2);
        boolean checked2= PreferenceManager.getDefaultSharedPreferences(this)
                .getBoolean("checkBox_bike_item_2", false);
        checkBox_bike_item_2.setChecked(checked2);

        CheckBox checkBox_bike_item_3 = (CheckBox) findViewById(R.id.checkBox_bike_item_3);
        boolean checked3 = PreferenceManager.getDefaultSharedPreferences(this)
                .getBoolean("checkBox_bike_item_3", false);
        checkBox_bike_item_3.setChecked(checked3);

        CheckBox checkBox_bike_item_4 = (CheckBox) findViewById(R.id.checkBox_bike_item_4);
        boolean checked4= PreferenceManager.getDefaultSharedPreferences(this)
                .getBoolean("checkBox_bike_item_4", false);
        checkBox_bike_item_4.setChecked(checked4);

        CheckBox checkBox_bike_item_5 = (CheckBox) findViewById(R.id.checkBox_bike_item_5);
        boolean checked5 = PreferenceManager.getDefaultSharedPreferences(this)
                .getBoolean("checkBox_bike_item_5", false);
        checkBox_bike_item_5.setChecked(checked5);

        CheckBox checkBox_bike_item_6 = (CheckBox) findViewById(R.id.checkBox_bike_item_6);
        boolean checked6= PreferenceManager.getDefaultSharedPreferences(this)
                .getBoolean("checkBox_bike_item_6", false);
        checkBox_bike_item_6.setChecked(checked6);

        CheckBox checkBox_bike_item_7 = (CheckBox) findViewById(R.id.checkBox_bike_item_7);
        boolean checked7 = PreferenceManager.getDefaultSharedPreferences(this)
                .getBoolean("checkBox_bike_item_7", false);
        checkBox_bike_item_7.setChecked(checked7);

        CheckBox checkBox_bike_item_8 = (CheckBox) findViewById(R.id.checkBox_bike_item_8);
        boolean checked8= PreferenceManager.getDefaultSharedPreferences(this)
                .getBoolean("checkBox_bike_item_8", false);
        checkBox_bike_item_8.setChecked(checked8);

        CheckBox checkBox_bike_item_9 = (CheckBox) findViewById(R.id.checkBox_bike_item_9);
        boolean checked9 = PreferenceManager.getDefaultSharedPreferences(this)
                .getBoolean("checkBox_bike_item_9", false);
        checkBox_bike_item_9.setChecked(checked9);

        CheckBox checkBox_bike_item_10 = (CheckBox) findViewById(R.id.checkBox_bike_item_10);
        boolean checked10 = PreferenceManager.getDefaultSharedPreferences(this)
                .getBoolean("checkBox_bike_item_10", false);
        checkBox_bike_item_10.setChecked(checked10);

        CheckBox checkBox_bike_item_11 = (CheckBox) findViewById(R.id.checkBox_bike_item_11);
        boolean checked11 = PreferenceManager.getDefaultSharedPreferences(this)
                .getBoolean("checkBox_bike_item_11", false);
        checkBox_bike_item_11.setChecked(checked11);

        CheckBox checkBox_bike_item_12 = (CheckBox) findViewById(R.id.checkBox_bike_item_12);
        boolean checked12= PreferenceManager.getDefaultSharedPreferences(this)
                .getBoolean("checkBox_bike_item_12", false);
        checkBox_bike_item_12.setChecked(checked12);

        CheckBox checkBox_bike_item_13 = (CheckBox) findViewById(R.id.checkBox_bike_item_13);
        boolean checked13 = PreferenceManager.getDefaultSharedPreferences(this)
                .getBoolean("checkBox_bike_item_13", false);
        checkBox_bike_item_13.setChecked(checked13);

        CheckBox checkBox_bike_item_14 = (CheckBox) findViewById(R.id.checkBox_bike_item_14);
        boolean checked14= PreferenceManager.getDefaultSharedPreferences(this)
                .getBoolean("checkBox_bike_item_14", false);
        checkBox_bike_item_14.setChecked(checked14);

        CheckBox checkBox_bike_item_15 = (CheckBox) findViewById(R.id.checkBox_bike_item_15);
        boolean checked15 = PreferenceManager.getDefaultSharedPreferences(this)
                .getBoolean("checkBox_bike_item_15", false);
        checkBox_bike_item_15.setChecked(checked15);
    }

    private void openMainActivity() {
        Intent intent = new Intent(this, MainActivity.class);
        startActivity(intent);
    }

    public void onCheckboxClicked(View view) {
        // Is the view now checked?
        boolean checked = ((CheckBox) view).isChecked();

        // Check which checkbox was clicked=
        switch(view.getId()) {
            case R.id.checkBox_bike_item_1:
                PreferenceManager.getDefaultSharedPreferences(this).edit()
                        .putBoolean("checkBox_bike_item_1", checked).commit();
                break;
            case R.id.checkBox_bike_item_2:
                PreferenceManager.getDefaultSharedPreferences(this).edit()
                        .putBoolean("checkBox_bike_item_2", checked).commit();
                break;
            case R.id.checkBox_bike_item_3:
                PreferenceManager.getDefaultSharedPreferences(this).edit()
                        .putBoolean("checkBox_bike_item_3", checked).commit();
                break;
            case R.id.checkBox_bike_item_4:
                PreferenceManager.getDefaultSharedPreferences(this).edit()
                        .putBoolean("checkBox_bike_item_4", checked).commit();
                break;
            case R.id.checkBox_bike_item_5:
                PreferenceManager.getDefaultSharedPreferences(this).edit()
                        .putBoolean("checkBox_bike_item_5", checked).commit();
                break;
            case R.id.checkBox_bike_item_6:
                PreferenceManager.getDefaultSharedPreferences(this).edit()
                        .putBoolean("checkBox_bike_item_6", checked).commit();
                break;
            case R.id.checkBox_bike_item_7:
                PreferenceManager.getDefaultSharedPreferences(this).edit()
                        .putBoolean("checkBox_bike_item_7", checked).commit();
                break;
            case R.id.checkBox_bike_item_8:
                PreferenceManager.getDefaultSharedPreferences(this).edit()
                        .putBoolean("checkBox_bike_item_8", checked).commit();
                break;
            case R.id.checkBox_bike_item_9:
                PreferenceManager.getDefaultSharedPreferences(this).edit()
                        .putBoolean("checkBox_bike_item_9", checked).commit();
                break;
            case R.id.checkBox_bike_item_10:
                PreferenceManager.getDefaultSharedPreferences(this).edit()
                        .putBoolean("checkBox_bike_item_10", checked).commit();
                break;
            case R.id.checkBox_bike_item_11:
                PreferenceManager.getDefaultSharedPreferences(this).edit()
                        .putBoolean("checkBox_bike_item_11", checked).commit();
                break;
            case R.id.checkBox_bike_item_12:
                PreferenceManager.getDefaultSharedPreferences(this).edit()
                        .putBoolean("checkBox_bike_item_12", checked).commit();
                break;
            case R.id.checkBox_bike_item_13:
                PreferenceManager.getDefaultSharedPreferences(this).edit()
                        .putBoolean("checkBox_bike_item_13", checked).commit();
                break;
            case R.id.checkBox_bike_item_14:
                PreferenceManager.getDefaultSharedPreferences(this).edit()
                        .putBoolean("checkBox_bike_item_14", checked).commit();
                break;
            case R.id.checkBox_bike_item_15:
                PreferenceManager.getDefaultSharedPreferences(this).edit()
                        .putBoolean("checkBox_bike_item_15", checked).commit();

        }
    }

    public void resetList(View view) {
        c1 = (CheckBox)findViewById(R.id.checkBox_bike_item_1);
        c2 = (CheckBox)findViewById(R.id.checkBox_bike_item_2);
        c3 = (CheckBox)findViewById(R.id.checkBox_bike_item_3);
        c4 = (CheckBox)findViewById(R.id.checkBox_bike_item_4);
        c5 = (CheckBox)findViewById(R.id.checkBox_bike_item_5);
        c6 = (CheckBox)findViewById(R.id.checkBox_bike_item_6);
        c7 = (CheckBox)findViewById(R.id.checkBox_bike_item_7);
        c8 = (CheckBox)findViewById(R.id.checkBox_bike_item_8);
        c9 = (CheckBox)findViewById(R.id.checkBox_bike_item_9);
        c10 = (CheckBox)findViewById(R.id.checkBox_bike_item_10);
        c11 = (CheckBox)findViewById(R.id.checkBox_bike_item_11);
        c12 = (CheckBox)findViewById(R.id.checkBox_bike_item_12);
        c13 = (CheckBox)findViewById(R.id.checkBox_bike_item_13);
        c14 = (CheckBox)findViewById(R.id.checkBox_bike_item_14);
        c15 = (CheckBox)findViewById(R.id.checkBox_bike_item_15);
        if(c1.isChecked()){
            c1.toggle();
            CheckBox checkBox_bike_item_1 = (CheckBox) findViewById(R.id.checkBox_bike_item_1);
            checkBox_bike_item_1.setChecked(false);
            PreferenceManager.getDefaultSharedPreferences(this).edit()
                    .putBoolean("checkBox_bike_item_1", false).commit();
        }
        if(c2.isChecked()){
            c2.toggle();
            CheckBox checkBox_bike_item_2 = (CheckBox) findViewById(R.id.checkBox_bike_item_2);
            checkBox_bike_item_2.setChecked(false);
            PreferenceManager.getDefaultSharedPreferences(this).edit()
                    .putBoolean("checkBox_bike_item_2", false).commit();
        }
        if(c3.isChecked()){
            c3.toggle();
            CheckBox checkBox_bike_item_3 = (CheckBox) findViewById(R.id.checkBox_bike_item_3);
            checkBox_bike_item_3.setChecked(false);
            PreferenceManager.getDefaultSharedPreferences(this).edit()
                    .putBoolean("checkBox_bike_item_3", false).commit();
        }
        if(c4.isChecked()){
            c4.toggle();
            CheckBox checkBox_bike_item_4 = (CheckBox) findViewById(R.id.checkBox_bike_item_4);
            checkBox_bike_item_4.setChecked(false);
            PreferenceManager.getDefaultSharedPreferences(this).edit()
                    .putBoolean("checkBox_bike_item_4", false).commit();
        }
        if(c5.isChecked()){
            c5.toggle();
            CheckBox checkBox_bike_item_5 = (CheckBox) findViewById(R.id.checkBox_bike_item_5);
            checkBox_bike_item_5.setChecked(false);
            PreferenceManager.getDefaultSharedPreferences(this).edit()
                    .putBoolean("checkBox_bikeitem_5", false).commit();
        }
        if(c6.isChecked()){
            c6.toggle();
            CheckBox checkBox_bike_item_6 = (CheckBox) findViewById(R.id.checkBox_bike_item_6);
            checkBox_bike_item_6.setChecked(false);
            PreferenceManager.getDefaultSharedPreferences(this).edit()
                    .putBoolean("checkBox_bike_item_6", false).commit();
        }
        if(c7.isChecked()){
            c7.toggle();
            CheckBox checkBox_bike_item_7 = (CheckBox) findViewById(R.id.checkBox_bike_item_7);
            checkBox_bike_item_7.setChecked(false);
            PreferenceManager.getDefaultSharedPreferences(this).edit()
                    .putBoolean("checkBox_bike_item_7", false).commit();
        }
        if(c8.isChecked()){
            c8.toggle();
            CheckBox checkBox_bike_item_8 = (CheckBox) findViewById(R.id.checkBox_bike_item_8);
            checkBox_bike_item_8.setChecked(false);
            PreferenceManager.getDefaultSharedPreferences(this).edit()
                    .putBoolean("checkBox_bike_item_8", false).commit();
        }
        if(c9.isChecked()){
            c9.toggle();
            CheckBox checkBox_bike_item_9 = (CheckBox) findViewById(R.id.checkBox_bike_item_9);
            checkBox_bike_item_9.setChecked(false);
            PreferenceManager.getDefaultSharedPreferences(this).edit()
                    .putBoolean("checkBox_bike_item_9", false).commit();
        }
        if(c10.isChecked()){
            c10.toggle();
            CheckBox checkBox_bike_item_10 = (CheckBox) findViewById(R.id.checkBox_bike_item_10);
            checkBox_bike_item_10.setChecked(false);
            PreferenceManager.getDefaultSharedPreferences(this).edit()
                    .putBoolean("checkBox_bike_item_10", false).commit();
        }
        if(c11.isChecked()){
            c11.toggle();
            CheckBox checkBox_bike_item_11 = (CheckBox) findViewById(R.id.checkBox_bike_item_11);
            checkBox_bike_item_11.setChecked(false);
            PreferenceManager.getDefaultSharedPreferences(this).edit()
                    .putBoolean("checkBox_bike_item_11", false).commit();
        }
        if(c12.isChecked()){
            c12.toggle();
            CheckBox checkBox_bike_item_12 = (CheckBox) findViewById(R.id.checkBox_bike_item_12);
            checkBox_bike_item_12.setChecked(false);
            PreferenceManager.getDefaultSharedPreferences(this).edit()
                    .putBoolean("checkBox_bike_item_12", false).commit();
        }
        if(c13.isChecked()){
            c13.toggle();
            CheckBox checkBox_bike_item_13 = (CheckBox) findViewById(R.id.checkBox_bike_item_13);
            checkBox_bike_item_13.setChecked(false);
            PreferenceManager.getDefaultSharedPreferences(this).edit()
                    .putBoolean("checkBox_bike_item_13", false).commit();
        }
        if(c14.isChecked()){
            c14.toggle();
            CheckBox checkBox_bike_item_14 = (CheckBox) findViewById(R.id.checkBox_bike_item_14);
            checkBox_bike_item_14.setChecked(false);
            PreferenceManager.getDefaultSharedPreferences(this).edit()
                    .putBoolean("checkBox_bike_item_14", false).commit();
        }
        if(c15.isChecked()){
            c15.toggle();
            CheckBox checkBox_bike_item_15 = (CheckBox) findViewById(R.id.checkBox_bike_item_15);
            checkBox_bike_item_15.setChecked(false);
            PreferenceManager.getDefaultSharedPreferences(this).edit()
                    .putBoolean("checkBox_bike_item_15", false).commit();
        }
    }
}
