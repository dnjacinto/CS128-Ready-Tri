package com.example.cs128_ace;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;

public class RecoveryActivity extends AppCompatActivity {
    CheckBox c1, c2, c3, c4, c5, c6, c7;
    private Button button_return;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_recovery);

        //back button
        button_return = (Button) findViewById(R.id.button_return);
        button_return.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                openMainActivity();
            }
        });

        //save state
        CheckBox checkBox_recovery_item_1 = (CheckBox) findViewById(R.id.checkBox_recovery_item_1);
        boolean checked1 = PreferenceManager.getDefaultSharedPreferences(this)
                .getBoolean("checkBox_recovery_item_1", false);
        checkBox_recovery_item_1.setChecked(checked1);

        CheckBox checkBox_recovery_item_2 = (CheckBox) findViewById(R.id.checkBox_recovery_item_2);
        boolean checked2= PreferenceManager.getDefaultSharedPreferences(this)
                .getBoolean("checkBox_recovery_item_2", false);
        checkBox_recovery_item_2.setChecked(checked2);

        CheckBox checkBox_recovery_item_3 = (CheckBox) findViewById(R.id.checkBox_recovery_item_3);
        boolean checked3 = PreferenceManager.getDefaultSharedPreferences(this)
                .getBoolean("checkBox_recovery_item_3", false);
        checkBox_recovery_item_3.setChecked(checked3);

        CheckBox checkBox_recovery_item_4 = (CheckBox) findViewById(R.id.checkBox_recovery_item_4);
        boolean checked4= PreferenceManager.getDefaultSharedPreferences(this)
                .getBoolean("checkBox_recovery_item_4", false);
        checkBox_recovery_item_4.setChecked(checked4);

        CheckBox checkBox_recovery_item_5 = (CheckBox) findViewById(R.id.checkBox_recovery_item_5);
        boolean checked5 = PreferenceManager.getDefaultSharedPreferences(this)
                .getBoolean("checkBox_recovery_item_5", false);
        checkBox_recovery_item_5.setChecked(checked5);

        CheckBox checkBox_recovery_item_6 = (CheckBox) findViewById(R.id.checkBox_recovery_item_6);
        boolean checked6= PreferenceManager.getDefaultSharedPreferences(this)
                .getBoolean("checkBox_recovery_item_6", false);
        checkBox_recovery_item_6.setChecked(checked6);

        CheckBox checkBox_recovery_item_7 = (CheckBox) findViewById(R.id.checkBox_recovery_item_7);
        boolean checked7= PreferenceManager.getDefaultSharedPreferences(this)
                .getBoolean("checkBox_recovery_item_7", false);
        checkBox_recovery_item_7.setChecked(checked7);
    }

    private void openMainActivity() {
        Intent intent = new Intent(this, MainActivity.class);
        startActivity(intent);
    }

    public void onCheckboxClicked(View view) {
        // Is the view now checked?
        boolean checked = ((CheckBox) view).isChecked();

        // Check which checkbox was clicked
        switch(view.getId()) {
            case R.id.checkBox_recovery_item_1:
                PreferenceManager.getDefaultSharedPreferences(this).edit()
                        .putBoolean("checkBox_recovery_item_1", checked).commit();
                break;
            case R.id.checkBox_recovery_item_2:
                PreferenceManager.getDefaultSharedPreferences(this).edit()
                        .putBoolean("checkBox_recovery_item_2", checked).commit();
                break;
            case R.id.checkBox_recovery_item_3:
                PreferenceManager.getDefaultSharedPreferences(this).edit()
                        .putBoolean("checkBox_recovery_item_3", checked).commit();
                break;
            case R.id.checkBox_recovery_item_4:
                PreferenceManager.getDefaultSharedPreferences(this).edit()
                        .putBoolean("checkBox_recovery_item_4", checked).commit();
                break;
            case R.id.checkBox_recovery_item_5:
                PreferenceManager.getDefaultSharedPreferences(this).edit()
                        .putBoolean("checkBox_recovery_item_5", checked).commit();
                break;
            case R.id.checkBox_recovery_item_6:
                PreferenceManager.getDefaultSharedPreferences(this).edit()
                        .putBoolean("checkBox_recovery_item_6", checked).commit();
                break;
            case R.id.checkBox_recovery_item_7:
                PreferenceManager.getDefaultSharedPreferences(this).edit()
                        .putBoolean("checkBox_recovery_item_7", checked).commit();
                break;
        }
    }

    public void resetList(View view) {
        c1 = (CheckBox)findViewById(R.id.checkBox_recovery_item_1);
        c2 = (CheckBox)findViewById(R.id.checkBox_recovery_item_2);
        c3 = (CheckBox)findViewById(R.id.checkBox_recovery_item_3);
        c4 = (CheckBox)findViewById(R.id.checkBox_recovery_item_4);
        c5 = (CheckBox)findViewById(R.id.checkBox_recovery_item_5);
        c6 = (CheckBox)findViewById(R.id.checkBox_recovery_item_6);
        c7 = (CheckBox)findViewById(R.id.checkBox_recovery_item_7);
        if(c1.isChecked()){
            c1.toggle();
            CheckBox checkBox_recovery_item_1 = (CheckBox) findViewById(R.id.checkBox_recovery_item_1);
            checkBox_recovery_item_1.setChecked(false);
            PreferenceManager.getDefaultSharedPreferences(this).edit()
                    .putBoolean("checkBox_recovery_item_1", false).commit();
        }
        if(c2.isChecked()){
            c2.toggle();
            CheckBox checkBox_recovery_item_2 = (CheckBox) findViewById(R.id.checkBox_recovery_item_2);
            checkBox_recovery_item_2.setChecked(false);
            PreferenceManager.getDefaultSharedPreferences(this).edit()
                    .putBoolean("checkBox_recovery_item_2", false).commit();
        }
        if(c3.isChecked()){
            c3.toggle();
            CheckBox checkBox_recovery_item_3 = (CheckBox) findViewById(R.id.checkBox_recovery_item_3);
            checkBox_recovery_item_3.setChecked(false);
            PreferenceManager.getDefaultSharedPreferences(this).edit()
                    .putBoolean("checkBox_recovery_item_3", false).commit();
        }
        if(c4.isChecked()){
            c4.toggle();
            CheckBox checkBox_recovery_item_4 = (CheckBox) findViewById(R.id.checkBox_recovery_item_4);
            checkBox_recovery_item_4.setChecked(false);
            PreferenceManager.getDefaultSharedPreferences(this).edit()
                    .putBoolean("checkBox_recovery_item_4", false).commit();
        }
        if(c5.isChecked()){
            c5.toggle();
            CheckBox checkBox_recovery_item_5 = (CheckBox) findViewById(R.id.checkBox_recovery_item_5);
            checkBox_recovery_item_5.setChecked(false);
            PreferenceManager.getDefaultSharedPreferences(this).edit()
                    .putBoolean("checkBox_recovery_item_5", false).commit();
        }
        if(c6.isChecked()){
            c6.toggle();
            CheckBox checkBox_recovery_item_6 = (CheckBox) findViewById(R.id.checkBox_recovery_item_6);
            checkBox_recovery_item_6.setChecked(false);
            PreferenceManager.getDefaultSharedPreferences(this).edit()
                    .putBoolean("checkBox_recovery_item_6", false).commit();
        }
        if(c7.isChecked()){
            c7.toggle();
            CheckBox checkBox_recovery_item_7 = (CheckBox) findViewById(R.id.checkBox_recovery_item_7);
            checkBox_recovery_item_7.setChecked(false);
            PreferenceManager.getDefaultSharedPreferences(this).edit()
                    .putBoolean("checkBox_recovery_item_7", false).commit();
        }
    }
}
