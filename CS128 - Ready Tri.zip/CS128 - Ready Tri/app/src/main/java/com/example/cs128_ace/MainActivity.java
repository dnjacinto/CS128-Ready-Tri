package com.example.cs128_ace;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;


public class MainActivity extends AppCompatActivity {
    private Button button_swimming;
    private Button button_cycling;
    private Button button_running;
    private Button button_recovery;
    private Button button_schedule;
    private ImageView imageView_swim;
    private ImageView imageView_bike;
    private ImageView imageView_run;
    private ImageView imageView_health;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //swimming
        button_swimming = (Button) findViewById(R.id.button_swimming);
        button_swimming.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                openSwimActivity();
            }
        });

        imageView_swim = (ImageView) findViewById(R.id.imageView_swim);
        imageView_swim.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                openSwimActivity();
            }
        });

        //cycling
        button_cycling = (Button) findViewById(R.id.button_cycling);
        button_cycling.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                openBikeActivity();
            }
        });

        imageView_bike = (ImageView) findViewById(R.id.imageView_bike);
        imageView_bike.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                openBikeActivity();
            }
        });
        //running
        button_running = (Button) findViewById(R.id.button_running);
        button_running.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                openRunActivity();
            }
        });

        imageView_run = (ImageView) findViewById(R.id.imageView_run);
        imageView_run.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                openRunActivity();
            }
        });
        //Off Field
        button_recovery = (Button) findViewById(R.id.button_recovery);
        button_recovery.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                openRecoveryActivity();
            }
        });
        imageView_health = (ImageView) findViewById(R.id.imageView_health);
        imageView_health.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                openRecoveryActivity();
            }
        });


        button_schedule = (Button) findViewById(R.id.button_schedule);
        button_schedule.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                openScheduleActivity();
            }
        });


    }

    private void openScheduleActivity() {
        Intent intent = new Intent(this, AlarmActivity.class);
        startActivity(intent);
    }

    private void openSwimActivity() {
        Intent intent = new Intent(this, SwimmingActivity.class);
        startActivity(intent);
    }

    private void openBikeActivity() {
        Intent intent = new Intent(this, CyclingActivity.class);
        startActivity(intent);
    }

    private void openRunActivity() {
        Intent intent = new Intent(this, RunningActivity.class);
        startActivity(intent);
    }

    private void openRecoveryActivity() {
        Intent intent = new Intent(this, RecoveryActivity.class);
        startActivity(intent);
    }


    /*
    IMG Reference:
        https://www.123rf.com/photo_90178030_stock-vector-vector-pixel-art-swim-sport-isolated.html?fromid=TnRHWUFBaDVnaDNiV2ZWSEhYN3dnZz09
        https://www.123rf.com/photo_96241688_stock-vector-pixel-art-woman-running-isolated-on-a-white-background-vector-.html
        http://gallery.wacom.com/gallery/Pixel-art-69-(The-bicycle)/8188683
        http://www.keywordbasket.com/aGVhbHRoIGJhciBwaXhlbCBhcnQ/

     */
}
